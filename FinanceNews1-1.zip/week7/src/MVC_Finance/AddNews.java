package MVC_Finance;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.login.News;
import com.login.SqlAboutNews;

/**
 * Servlet implementation class AddNews
 */
public class AddNews extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddNews() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		System.out.print("��ʼ��");
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		//System.out.println("��ת��������2");
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		News news=new News();
//		news.setTime(new Date().getTime());
//		news.setTitle("���ǵ�һ����������");
//		news.setContent("���´����ǡ�����������������");
//		news.setType("ծȯ");
//		news.setImages("http://www.baiduimage.com");
		request.setCharacterEncoding("utf-8");
		news.setTime(new Date().getTime());
		news.setTitle(request.getParameter("title"));
		news.setContent(request.getParameter("content"));
		news.setType(request.getParameter("type"));
		news.setImages(request.getParameter("href"));
		news.setViewNum(0);
		SqlAboutNews sqlAboutNews=new SqlAboutNews();
		sqlAboutNews.insert(news);
		System.out.println("���ӳɹ�");
	}

}
