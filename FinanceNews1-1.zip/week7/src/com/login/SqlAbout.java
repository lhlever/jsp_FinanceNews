package com.login;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SqlAbout {
	PreparedStatement preparedStatement=null;
	ResultSet resultSet=null;
	public Connection getConnection() {
		Connection connection=null;
		String driverString="com.microsoft.sqlserver.jdbc.SQLServerDriver";
		String url="jdbc:sqlserver://localhost:1433;dataBasename=mydb";
		String user="sa";
		String pwd="123456";
		try {
			Class.forName(driverString);
			connection=DriverManager.getConnection(url,user,pwd);
		} catch (ClassNotFoundException e) {
			// TODO: handle exception
			e.printStackTrace();
		}catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return connection;
	}
	public void closeConn(ResultSet resultSet,Statement statement,Connection connection) {
		try {
			resultSet.close();
			statement.close();
			connection.close();
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}	
	}
	public void closeConn(ResultSet resultSet,PreparedStatement statement,Connection connection) {
		try {
			resultSet.close();
			statement.close();
			connection.close();
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}	
	}
	public void closeConn(Statement statement,Connection connection) {
		try {
			statement.close();
			connection.close();
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}	
	}
	public boolean query(User user) {
		try {
			String sql="select * from login where username=? and pwd=?";
			Connection connection=getConnection();
			preparedStatement =connection.prepareStatement(sql);
			preparedStatement.setString(1,user.getUsername());
			preparedStatement.setString(2,user.getPwd());
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next()) {
				closeConn(resultSet, preparedStatement, connection);
				return true;
			}else {
				closeConn(resultSet, preparedStatement, connection);
				return false;
			}
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return false;
	}
	public boolean insert(User user) {
		try {
			String sql="insert into login values(?,?,?,?)";
			Connection connection=getConnection();
			preparedStatement =connection.prepareStatement(sql);
			preparedStatement.setString(1,user.getUsername());
			preparedStatement.setString(2,user.getPwd());
			preparedStatement.setString(3,user.getRole());
			preparedStatement.setString(4,user.getEnable());
			if(preparedStatement.executeUpdate()==1) {
				closeConn(preparedStatement, connection);
				return true;
			}else {
				closeConn(preparedStatement, connection);
				return false;
			}
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return false;
	}
	public boolean delete(User user) {
		try {
			String sql="delete from login where username=? and pwd=?";
			Connection connection=getConnection();
			preparedStatement =connection.prepareStatement(sql);
			preparedStatement.setString(1,user.getUsername());
			preparedStatement.setString(2,user.getPwd());
			if(preparedStatement.executeUpdate()==1) {
				closeConn(resultSet, preparedStatement, connection);
				return true;
			}else {
				closeConn(resultSet, preparedStatement, connection);
				return false;
			}
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return false;
	}
	public boolean change(User user) {
		try {
			String sql="update login set pwd=? where username=?";
			Connection connection=getConnection();
			preparedStatement =connection.prepareStatement(sql);
			preparedStatement.setString(1,user.getPwd());
			preparedStatement.setString(2,user.getUsername());
			if(preparedStatement.executeUpdate()==1) {
				closeConn(resultSet, preparedStatement, connection);
				return true;
			}else {
				closeConn(resultSet, preparedStatement, connection);
				return false;
			}
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return false;
	}
}
