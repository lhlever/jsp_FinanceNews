package com.login;

import java.io.IOException;

import javax.jms.Session;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet Filter implementation class TestFilter
 */
public class TestFilter implements Filter {

    /**
     * Default constructor. 
     */
    public TestFilter() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		// place your code here

		// pass the request along the filter chain
		System.out.println("��ʼ����");
		HttpServletRequest request2=(HttpServletRequest)request; 
		HttpServletResponse response2=(HttpServletResponse)response;
//		String checkString=(String)request2.getSession().getAttribute("checkName");
//		System.out.println("�û���Ϊ��"+checkString);
		String checkString=request.getParameter("username");
		if(checkString==null||checkString.charAt(0)=='T') {
			request2.getRequestDispatcher("error.jsp").forward(request2, response2);
		}else {
//			request2.getRequestDispatcher("welcome.jsp").forward(request2, response2);
			chain.doFilter(request, response);
		}
//		chain.doFilter(request, response);
		System.out.println("���˽���");
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
