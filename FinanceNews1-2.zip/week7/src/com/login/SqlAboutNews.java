package com.login;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SqlAboutNews {
	PreparedStatement preparedStatement=null;
	ResultSet resultSet=null;
	public Connection getConnection() {
		Connection connection=null;
		String driverString="com.microsoft.sqlserver.jdbc.SQLServerDriver";
		String url="jdbc:sqlserver://localhost:1433;dataBasename=mydb";
		String user="sa";
		String pwd="123456";
		try {
			Class.forName(driverString);
			connection=DriverManager.getConnection(url,user,pwd);
		} catch (ClassNotFoundException e) {
			// TODO: handle exception
			e.printStackTrace();
		}catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return connection;
	}
	public void closeConn(ResultSet resultSet,Statement statement,Connection connection) {
		try {
			resultSet.close();
			statement.close();
			connection.close();
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}	
	}
	public void closeConn(ResultSet resultSet,PreparedStatement statement,Connection connection) {
		try {
			resultSet.close();
			statement.close();
			connection.close();
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}	
	}
	public void closeConn(Statement statement,Connection connection) {
		try {
			statement.close();
			connection.close();
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}	
	}
	public ResultSet queryDetail(String string) {
		try {
			String sql="select * from news where timeStamp=?";
			Connection connection=getConnection();
			preparedStatement =connection.prepareStatement(sql);
			preparedStatement.setString(1,string);
			resultSet=preparedStatement.executeQuery();
			ResultSet tempResultSet=resultSet;
			if(tempResultSet.next()) {
//				closeConn(resultSet, preparedStatement, connection);
				System.out.println("�з���������");
				return resultSet;
			}else {
//				closeConn(resultSet, preparedStatement, connection);
				return null;
			}
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return null;
	}
	
	
	
	public boolean plusViewNum(String string,int num) {
		try {
			String sql="update news set viewNum=? where timeStamp=?";
			Connection connection=getConnection();
			preparedStatement =connection.prepareStatement(sql);
			preparedStatement.setInt(1,num);
			preparedStatement.setString(2,string);
			if(preparedStatement.executeUpdate()==1) {
				//closeConn(resultSet, preparedStatement, connection);
				return true;
			}else {
				//closeConn(resultSet, preparedStatement, connection);
				return false;
			}
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return false;
	}
	public ResultSet queryTopTime() {
		try {
			String sql="select top 5 news.* from news order by timeStamp desc";
			Connection connection=getConnection();
			preparedStatement =connection.prepareStatement(sql);
			resultSet=preparedStatement.executeQuery();
			ResultSet tempResultSet=resultSet;
			if(tempResultSet.next()) {
//				closeConn(resultSet, preparedStatement, connection);
				System.out.println("�з���������");
				return resultSet;
			}else {
//				closeConn(resultSet, preparedStatement, connection);
				return null;
			}
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return null;
	}
	
	
	
	
	public ResultSet queryTop() {
		try {
			String sql="select top 5 news.* from news order by viewNum desc";
			Connection connection=getConnection();
			preparedStatement =connection.prepareStatement(sql);
			resultSet=preparedStatement.executeQuery();
			ResultSet tempResultSet=resultSet;
			if(tempResultSet.next()) {
//				closeConn(resultSet, preparedStatement, connection);
				System.out.println("�з���������");
				return resultSet;
			}else {
//				closeConn(resultSet, preparedStatement, connection);
				return null;
			}
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return null;
	}
	
	
	
	public ResultSet queryType(String string) {
		try {
			String sql="select * from news where type=?";
			Connection connection=getConnection();
			preparedStatement =connection.prepareStatement(sql);
			preparedStatement.setString(1,string);
			resultSet=preparedStatement.executeQuery();
			ResultSet tempResultSet=resultSet;
			if(tempResultSet.next()) {
//				closeConn(resultSet, preparedStatement, connection);
				System.out.println("�з���������");
				return resultSet;
			}else {
//				closeConn(resultSet, preparedStatement, connection);
				return null;
			}
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return null;
	}
	
	
	public ResultSet queryAll() {
		try {
			String sql="select * from news";
			Connection connection=getConnection();
			preparedStatement =connection.prepareStatement(sql);
			resultSet=preparedStatement.executeQuery();
			ResultSet tempResultSet=resultSet;
			if(tempResultSet.next()) {
//				closeConn(resultSet, preparedStatement, connection);
				System.out.println("�з���������");
				return resultSet;
			}else {
//				closeConn(resultSet, preparedStatement, connection);
				return null;
			}
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return null;
	}
	
	public boolean insert(News news) {
		try {
			String sql="insert into news values(?,?,?,?,?,?)";
			Connection connection=getConnection();
			preparedStatement =connection.prepareStatement(sql);
			preparedStatement.setLong(1,news.getTime());
			preparedStatement.setString(2,news.getTitle());
			preparedStatement.setString(3,news.getContent());
			preparedStatement.setString(4,news.getType());
			preparedStatement.setString(5,news.getImages());
			System.out.println("�ɹ���������ǰ����");
			preparedStatement.setInt(6,news.getViewNum());
			if(preparedStatement.executeUpdate()==1) {
				System.out.println("ִ��������");
				closeConn(preparedStatement, connection);
				System.out.println("�ɹ��������");
				return true;
			}else {
				System.out.println("û��ִ��������");
				closeConn(preparedStatement, connection);
				System.out.println("ʧ���������");
				return false;
			}
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return false;
	}
	
	
	
	
	public boolean delete(String string) {
		System.out.println("����������"+string);
//		return true;
		try {
			String sql="delete from news where timeStamp=?";
			Connection connection=getConnection();
			preparedStatement =connection.prepareStatement(sql);
			preparedStatement.setString(1,string);
			if(preparedStatement.executeUpdate()==1) {
				//closeConn(preparedStatement, connection);
				System.out.println("ɾ���ɹ�");
				return true;
			}else {
				//closeConn(preparedStatement, connection);
				return false;
			}
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return false;
	}
	public boolean change(User user) {
		try {
			String sql="update login set pwd=? where username=?";
			Connection connection=getConnection();
			preparedStatement =connection.prepareStatement(sql);
			preparedStatement.setString(1,user.getPwd());
			preparedStatement.setString(2,user.getUsername());
			if(preparedStatement.executeUpdate()==1) {
				closeConn(resultSet, preparedStatement, connection);
				return true;
			}else {
				closeConn(resultSet, preparedStatement, connection);
				return false;
			}
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return false;
	}
}
